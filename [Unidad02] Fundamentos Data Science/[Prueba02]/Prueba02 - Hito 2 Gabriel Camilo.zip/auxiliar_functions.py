import pandas as pd # Permite trabajar con data frame
import numpy as np # Agrega mayor soporte para vectores y matrices

# La funcion se encarga de replazar los valores de una columna por los indicados, agrupando segun lo solicitado y crear columnas binarias con los datos de la columana indicada
# Input:
# 	variables_originales: array con datos originales del data frame
# 	variables: array con nuevo nombre de las variables 
# 	columna: nombre de la columna sobre la que se trabajara
# 	df: dataframe con el que se trabajara
# Output:
# 	Retorna un dataframe con las modificaciones en la columna señalada y las nuevas columnas binarias
def bin_and_remplace(variables_originales, variables, columna, df):
    df[columna] = df[columna].replace(variables_originales,variables)
    for variable in variables:
    	if (df[columna].value_counts().index[0] != variable):
    		df['bin_'+variable.lower()] = np.where(df[columna] == variable, 1, 0)
    return df