from listas_uno import *
import velocidad

for lista_uno in listas_uno:
	if lista_uno[3]:
		print(lista_uno[0])
