i = 0
for i in range(0,50):
	print("Iteración {}".format(i+1))
