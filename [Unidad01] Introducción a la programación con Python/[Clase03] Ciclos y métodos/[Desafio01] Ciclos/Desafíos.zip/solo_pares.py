n = int(input("Ingrese un número para comenzar la cuenta\n"))
for i in range(0, n + 1, 2):
	print(i)