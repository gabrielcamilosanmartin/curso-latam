import sys
n = int(sys.argv[1])

lorem_ipsum = """Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vel hendrerit diam. Phasellus aliquet elit et magna ultrices, ut cursus tortor blandit. Proin eget tellus fermentum, sollicitudin ligula ut, lobortis elit. Maecenas at neque tellus. Vivamus semper metus at suscipit elementum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc dolor lectus, tincidunt nec ex sed, tristique feugiat nunc. In mollis sem leo, ut convallis odio tempus sit amet.\n"""
for i in range(0, n):
	print (lorem_ipsum)