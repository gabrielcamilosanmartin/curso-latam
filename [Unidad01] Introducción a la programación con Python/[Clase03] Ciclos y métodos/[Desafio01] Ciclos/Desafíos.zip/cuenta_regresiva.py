cuenta_regresiva = int(input("Ingrese un número para comenzar la cuenta\n"))
while cuenta_regresiva > 0:
	print("Iteración {}".format(cuenta_regresiva))
	cuenta_regresiva -= 1