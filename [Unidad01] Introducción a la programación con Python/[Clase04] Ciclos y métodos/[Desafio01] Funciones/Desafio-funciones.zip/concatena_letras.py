def gen( n_letras):
	abecedatio = 'abcdefghijklmnopqrstuvwxyz'
	return abecedatio[:n_letras]